package com.selvaggi.google;

public class TrafficLight {

    public int id;
    public boolean isGreen;
    public int greenTime;


    public TrafficLight() {

    }
}
