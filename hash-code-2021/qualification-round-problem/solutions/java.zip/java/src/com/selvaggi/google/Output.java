package com.selvaggi.google;

public class Output {

    public int numberOfIntersection;


    public String toString() {
        StringBuilder out = new StringBuilder();

        return out.append("")
                .toString();
    }
}
